pywikibot.userinterfaces package
================================

.. automodule:: pywikibot.userinterfaces

Submodules
----------

pywikibot.userinterfaces.gui module
-----------------------------------

.. automodule:: pywikibot.userinterfaces.gui

pywikibot.userinterfaces.terminal\_interface module
---------------------------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface

pywikibot.userinterfaces.terminal\_interface\_base module
---------------------------------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface_base

pywikibot.userinterfaces.terminal\_interface\_unix module
---------------------------------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface_unix

pywikibot.userinterfaces.terminal\_interface\_win32 module
----------------------------------------------------------

.. automodule:: pywikibot.userinterfaces.terminal_interface_win32

pywikibot.userinterfaces.transliteration module
-----------------------------------------------

.. automodule:: pywikibot.userinterfaces.transliteration

pywikibot.userinterfaces.win32\_unicode module
----------------------------------------------

.. automodule:: pywikibot.userinterfaces.win32_unicode


