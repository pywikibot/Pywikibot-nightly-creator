pywikibot.page package
=======================

.. automodule:: pywikibot.page
