scripts.maintenance utility scripts
===================================

.. automodule:: scripts.maintenance

Submodules
----------

scripts.maintenance.cache script
--------------------------------

.. automodule:: scripts.maintenance.cache
   :ignore-module-all:

scripts.maintenance.colors script
---------------------------------

.. automodule:: scripts.maintenance.colors

scripts.maintenance.compat2core script
--------------------------------------

.. automodule:: scripts.maintenance.compat2core

scripts.maintenance.download\_dump script
-----------------------------------------

.. automodule:: scripts.maintenance.download_dump

scripts.maintenance.make\_i18n\_dict script
-------------------------------------------

.. automodule:: scripts.maintenance.make_i18n_dict

scripts.maintenance.wikimedia\_sites script
-------------------------------------------

.. automodule:: scripts.maintenance.wikimedia_sites


