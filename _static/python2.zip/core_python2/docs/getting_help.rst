Getting help
------------

.. note::
   Please see `Manual:Pywikibot/Communication <https://www.mediawiki.org/wiki/Manual:Pywikibot/Communication>`_.

.. tip::
   Please report bugs at `Phabricator <https://phabricator.wikimedia.org/>`_.
   You may use `this report form <https://phabricator.wikimedia.org/maniphest/task/edit/form/1/?tags=pywikibot-core>`_.
