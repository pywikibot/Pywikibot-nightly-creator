# -*- coding: utf-8 -*-
"""Module providing several layers of data access to the wiki."""
