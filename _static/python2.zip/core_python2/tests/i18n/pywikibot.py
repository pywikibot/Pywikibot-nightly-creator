# -*- coding: utf-8 -*-
"""i18n message bundle called 'pywikibot' to fool the i18n loader."""
#
# (C) Pywikibot team, 2014-2018
#
# Distributed under the terms of the MIT license.
#
from __future__ import absolute_import, division, unicode_literals

msg = {}
