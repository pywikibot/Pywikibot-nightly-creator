# -*- coding: utf-8 -*-
"""Fixes implementation which overwrites the variable."""
#
# (C) Pywikibot team, 2015-2018
#
# Distributed under the terms of the MIT license.
#
from __future__ import absolute_import, division, unicode_literals

# Just kill the old value suffices
fixes = {}
