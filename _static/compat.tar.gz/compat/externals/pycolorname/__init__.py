# -*- coding: utf-8 -*-
"""
Created on Sat Jun 30 22:57:26 2012

@author: drtrigon
"""

import pantone, RAL

# NCS (http://de.wikipedia.org/wiki/Natural_Color_System) not implemented ...
