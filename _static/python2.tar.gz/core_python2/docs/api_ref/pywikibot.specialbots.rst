pywikibot.specialbots package
=============================

.. automodule:: pywikibot.specialbots
