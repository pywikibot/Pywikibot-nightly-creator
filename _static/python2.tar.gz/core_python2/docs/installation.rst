Installation
------------

.. note::
   Please see the documentation at `Manual:Pywikibot/Installation <https://www.mediawiki.org/wiki/Manual:Pywikibot/Installation>`_
