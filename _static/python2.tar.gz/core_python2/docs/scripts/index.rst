Scripts reference
-----------------

Provided scripts by pywikibot
=============================

Pywikibot framework has a lot of ready-to-use scripts for several tasks.
In general the usage and options of all scripts may be shown by using the command
``<scriptname> -help``


Contents
========

.. toctree::
   :glob:

   *


