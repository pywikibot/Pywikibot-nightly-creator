Licenses
========

The framework itself and this documentation are available under the
:ref:`MIT license <licenses-MIT>`; manual pages on mediawiki.org are
available under the `CC-BY-SA 3.0`_ license.

.. _licenses-MIT:

MIT License
-----------
The framework is available under the MIT license:

.. include:: ../LICENSE


.. _CC-BY-SA 3.0: http://creativecommons.org/licenses/by-sa/3.0/
