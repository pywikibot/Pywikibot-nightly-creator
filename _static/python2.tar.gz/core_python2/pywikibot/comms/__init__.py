# -*- coding: utf-8 -*-
"""Communication layer."""
