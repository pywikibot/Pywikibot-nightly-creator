# -*- coding: utf-8 -*-
"""Test i18n data package."""
