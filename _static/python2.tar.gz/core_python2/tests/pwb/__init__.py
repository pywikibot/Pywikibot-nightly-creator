# -*- coding: utf-8 -*-
"""Dummy package initialisation."""
